import random
number_to_guess = random.randint(1, 100)
guess_no = 0

print("Welcome to the number guessing game!")
print("Select a random number between 1 and 100")
print("Guess the number!")
while True:
   
    user_choice = int(input("Enter your guess: "))
    guess_no += 1
    
    if user_choice < number_to_guess:
        print("Too low! Try again.")
    elif user_choice > number_to_guess:
        print("Too high! Try again.")
    else:
        print(f"Congratulations! You guessed the number in {guess_no} attempts.")
        break
